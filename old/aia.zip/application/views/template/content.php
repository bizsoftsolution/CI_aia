<div class="content-wrapper">

  <!-- Content area -->
  <div class="content">
    <div class="breadcrumb-line breadcrumb-line-component"><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
			 <ul class="breadcrumb">
					<li><a href=""><i class="icon-home2 position-left"></i> Home</a></li>
					<li><a href="">Dashboard</a></li>
					<li class="active">Basic inputs</li>
				</ul>
    	</div>
      <br>
    <!-- Main charts -->
    <div class="row">
      <div class="col-lg-12">
        <!-- Traffic sources -->

        <div class="panel panel-flat">
          <div class="panel-heading">
            <h6 class="panel-title">Traffic sources</h6>
          </div>
          <div class="container-fluid">

<!-- content Starts Here-->

          </div>
        </div>
        <!-- /traffic sources -->

      </div>
    </div>
    <!-- /dashboard content -->
